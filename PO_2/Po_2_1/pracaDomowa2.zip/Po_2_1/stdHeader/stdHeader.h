#ifndef STD_HEADER_h
#define STD_HEADER_h
// dummy file for geting rid of muliple declaritons of the same iostream
#include <iostream>
using namespace std;
#endif